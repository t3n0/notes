from setuptools import setup, Extension

myextensions = [Extension(name = "integrate.fastmodule", sources = ["integrate/fastmodule.c"])]
setup( ext_modules = myextensions )

