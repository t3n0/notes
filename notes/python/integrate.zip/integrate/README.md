# Flat layout package example

Simple readme for a package.

This package has a flat layout, i.e. no `/src/` directory.

The package just shows how to compile, import and test cython code.

