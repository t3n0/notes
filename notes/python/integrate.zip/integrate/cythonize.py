from setuptools import Extension, setup
from Cython.Build import cythonize

myextensions = [Extension(name = "integrate.fastmodule", sources = ["integrate/fastmodule.pyx"])]
setup(ext_modules = cythonize(myextensions, annotate = True, language_level ="3str"))
