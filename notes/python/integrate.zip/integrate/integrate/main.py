import fastmodule as fm
import slowmodule as sm
from time import perf_counter as clock

a = 1
b = 4
N = 10000000

start = clock()
res = sm.integrate_f(a, b, N)
time = clock() - start
print(f" Slow python: result = {res:0.3f}, time {time:0.5f} seconds.")

start = clock()
res = fm.integrate_f(a, b, N)
time = clock() - start
print(f" Slow cython: result = {res:0.3f}, time {time:0.5f} seconds.")

start = clock()
res = fm.integrate_fastf(a, b, N)
time = clock() - start
print(f" Fast cython: result = {res:0.3f}, time {time:0.5f} seconds.")

