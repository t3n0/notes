from setuptools import setup, Extension

myextensions = [
    Extension(name = "carwash.fastmodule", sources = ["carwash/fastmodule.c"])
]

setup( ext_modules = myextensions )

