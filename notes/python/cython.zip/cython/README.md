# Flat layout package example

Simple readme for a package.

This package has a flat layout, i.e. no `/src/` directory.

There are 2 subfolders:
	- carwash, with an `__init__.py` file, contains some modules
	- tools, does not have `__init__.py`, contains some other modules

The package also defines some command line entries that run some functions.

