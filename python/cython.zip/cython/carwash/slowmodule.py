'''
Python module.

It contains the same functions of its Cython counterpart in this package.
The functions defined here should be quite slow compared to their Cython
version in the other module.
'''

def f(x):
    return x ** 2 - x


def integrate_f(a, b, N):
    s = 0
    dx = (b - a) / N
    for i in range(N):
        s += f(a + i * dx)
    return s * dx

