'''
A simple module with a function
'''

# module2
print('Hello from the drying module')

def dry():
	'''
	This function prints some text
	'''
	print('We are drying super hard!')

