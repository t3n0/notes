from setuptools import setup, Extension

myextensions = [
    Extension(name = "carwash.fast", sources = ["carwash/fastmodule.c"])
]

setup( ext_modules = myextensions )

