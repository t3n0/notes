'''
A module that defines a tool to be used in a command line script
'''

def spray(color='pink'):
	'''
	This tool spray the desire color.
	Parameters:
		color (str):	color to spray
	'''
	print(f'We spray {color} everywhere!')

