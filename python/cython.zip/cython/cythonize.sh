cythonize -i -a carwash/fastmodule.pyx

