'''
A simple module with an import and a function
'''

import numpy as np

print('Hello from the washing module')

def wash(task='washing'):
	'''
	This function prints some text
	Parameters:
		task (str):		the task to execute
	'''
	print(f'We are {text} super hard')
	print(np.pi)

