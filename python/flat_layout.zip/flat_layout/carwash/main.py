'''
Main module with the command line and GUI functions.
These are called as scripts from the terminal.
'''

import matplotlib.pyplot as plt

def main_cli():
	'''
	Command line script: it prints some text.
	'''
	print('Carwash from the command line tool')


def main_gui():
	'''
	GUI scripts: it displays some plot.
	'''
	plt.plot([1,5,2,5,3,2,3,4,1])
	plt.title('Carwash from GUI')
	plt.show()

